﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyShop
{
    public partial class forUsers : Form
    {
        public forUsers()
        {
            InitializeComponent();
        }

        private void forUsers_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.toy_shopDataSet.Товары);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.toy_shopDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Работники". При необходимости она может быть перемещена или удалена.
            this.работникиTableAdapter.Fill(this.toy_shopDataSet.Работники);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Покупатели". При необходимости она может быть перемещена или удалена.
            this.покупателиTableAdapter.Fill(this.toy_shopDataSet.Покупатели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Магазины". При необходимости она может быть перемещена или удалена.
            this.магазиныTableAdapter.Fill(this.toy_shopDataSet.Магазины);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "toy_shopDataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.toy_shopDataSet.Заказы);

        }
    }
}
