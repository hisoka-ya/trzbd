﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ToyShop
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=HISOKA\\SQLEXPRESS;Initial Catalog=\"Toy shop\";Integrated Security=True");
        Class1 class1 = new Class1();

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.товарыTableAdapter.Fill(this.toy_shopDataSet.Товары);
            this.страныTableAdapter.Fill(this.toy_shopDataSet.Страны);
            this.работникиTableAdapter.Fill(this.toy_shopDataSet.Работники);
            this.магазиныTableAdapter.Fill(this.toy_shopDataSet.Магазины);
            this.заказыTableAdapter.Fill(this.toy_shopDataSet.Заказы);
            this.покупателиTableAdapter.Fill(this.toy_shopDataSet.Покупатели);
        }

        //таблица покупатели
        private void dataGridView4_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView4.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView4.SelectedRows[0];
                textBox4.Text = selectedRow.Cells["dataGridViewTextBoxColumn3"].Value?.ToString() ?? string.Empty;
                textBox1.Text = selectedRow.Cells["dataGridViewTextBoxColumn4"].Value?.ToString() ?? string.Empty;
                textBox2.Text = selectedRow.Cells["dataGridViewTextBoxColumn5"].Value?.ToString() ?? string.Empty;
                textBox3.Text = selectedRow.Cells["dataGridViewTextBoxColumn6"].Value?.ToString() ?? string.Empty;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Покупатели (Имя, Отчество, Телефон) VALUES (@Имя, @Отчество, @Телефон)", con);
            command.Parameters.AddWithValue("@Имя", textBox1.Text);
            command.Parameters.AddWithValue("@Отчество", textBox2.Text);
            command.Parameters.AddWithValue("@Телефон", textBox3.Text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Покупатели", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView4.DataSource = table;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView4, textBox4.Text, "Покупатели");
        }
        private void RadioButton_CheckedChanged1(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView4, textBox7.Text, "Покупатели");
        }
        private void RadioButton_CheckedChanged2(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView4, "Покупатели");
        }

        //таблица заказы
        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
                textBox10.Text = selectedRow.Cells["idDataGridViewTextBoxColumn1"].Value?.ToString() ?? string.Empty;
                textBox5.Text = selectedRow.Cells["покупательDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox6.Text = selectedRow.Cells["магазинDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox8.Text = selectedRow.Cells["датазаказаDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox31.Text = selectedRow.Cells["суммазаказаDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox32.Text = selectedRow.Cells["товарыDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox33.Text = selectedRow.Cells["работникDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Заказы (Покупатель, Магазин, Дата_заказа, Сумма_заказа, Товары, Работник) VALUES (@2, @3, @4, @5, @6, @7)", con);
            command.Parameters.AddWithValue("@2", textBox5.Text);
            command.Parameters.AddWithValue("@3", textBox6.Text);
            command.Parameters.AddWithValue("@4", textBox8.Text);
            command.Parameters.AddWithValue("@5", textBox31.Text);
            command.Parameters.AddWithValue("@6", textBox32.Text);
            command.Parameters.AddWithValue("@7", textBox33.Text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Заказы", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView2.DataSource = table;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView2, textBox10.Text, "Заказы");
        }
        private void RadioButton_CheckedChanged3(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView2, textBox9.Text, "Заказы");
        }
        private void RadioButton_CheckedChanged4(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView2, "Заказы");
        }
        //таблица магазины
        private void dataGridView3_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView3.SelectedRows[0];
                textBox15.Text = selectedRow.Cells["idDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox11.Text = selectedRow.Cells["адрессDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox12.Text = selectedRow.Cells["телефонDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox13.Text = selectedRow.Cells["рейтингDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Магазины (Адресс, телефон, Рейтинг) VALUES (@1, @2, @3)", con);
            command.Parameters.AddWithValue("@1", textBox11.Text);
            command.Parameters.AddWithValue("@2", textBox12.Text);
            command.Parameters.AddWithValue("@3", Math.Round(float.Parse(textBox13.Text), 2));
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Магазины", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView3.DataSource = table;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView3, textBox15.Text, "Магазины");
        }
        private void RadioButton_CheckedChanged5(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView3, textBox14.Text, "Магазины");
        }
        private void RadioButton_CheckedChanged6(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView3, "Магазины");
        }
        //таблица работники
        private void dataGridView5_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView5.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView5.SelectedRows[0];
                textBox20.Text = selectedRow.Cells["idDataGridViewTextBoxColumn3"].Value?.ToString() ?? string.Empty;
                textBox16.Text = selectedRow.Cells["имяDataGridViewTextBoxColumn1"].Value?.ToString() ?? string.Empty;
                textBox17.Text = selectedRow.Cells["фамилияDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox18.Text = selectedRow.Cells["телефонDataGridViewTextBoxColumn2"].Value?.ToString() ?? string.Empty;
                textBox34.Text = selectedRow.Cells["магазинDataGridViewTextBoxColumn1"].Value?.ToString() ?? string.Empty;
                textBox35.Text = selectedRow.Cells["должностьDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Работники (Имя, Фамилия, телефон, Магазин, Должность) VALUES (@1, @2, @3, @4, @5)", con);
            command.Parameters.AddWithValue("@1", textBox16.Text);
            command.Parameters.AddWithValue("@2", textBox17.Text);
            command.Parameters.AddWithValue("@3", textBox18.Text);
            command.Parameters.AddWithValue("@4", textBox34.Text);
            command.Parameters.AddWithValue("@5", textBox35.Text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Работники", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView5.DataSource = table;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView5, textBox20.Text, "Работники");
        }
        private void RadioButton_CheckedChanged7(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView5, textBox19.Text, "Работники");
        }
        private void RadioButton_CheckedChanged8(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView5, "Работники");
        }
        //таблица страны
        private void dataGridView6_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView6.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView6.SelectedRows[0];
                textBox25.Text = selectedRow.Cells["idDataGridViewTextBoxColumn4"].Value?.ToString() ?? string.Empty;
                textBox21.Text = selectedRow.Cells["странаDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox22.Text = selectedRow.Cells["валютаDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
            }
        }
        private void button9_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Страны (Страна, Валюта) VALUES (@1, @2)", con);
            command.Parameters.AddWithValue("@1", textBox21.Text);
            command.Parameters.AddWithValue("@2", textBox22.Text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Страны", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView6.DataSource = table;
        }
        private void button10_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView6, textBox25.Text, "Страны");
        }
        private void RadioButton_CheckedChanged9(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView6, textBox24.Text, "Страны");
        }
        private void RadioButton_CheckedChanged10(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView6, "Страны");
        }
        //таблица товары
        private void dataGridView7_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView7.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView7.SelectedRows[0];
                textBox30.Text = selectedRow.Cells["idDataGridViewTextBoxColumn5"].Value?.ToString() ?? string.Empty;
                textBox26.Text = selectedRow.Cells["названиеDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox27.Text = selectedRow.Cells["описаниеDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox28.Text = selectedRow.Cells["ценаDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox23.Text = selectedRow.Cells["количествонаскладеDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
                textBox36.Text = selectedRow.Cells["странаDataGridViewTextBoxColumn1"].Value?.ToString() ?? string.Empty;
                textBox37.Text = selectedRow.Cells["изображениеDataGridViewTextBoxColumn"].Value?.ToString() ?? string.Empty;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Товары (Название, Описание, Цена, Количество_на_складе, Страна, Изображение) VALUES (@1, @2, @3, @4, @5, @6)", con);
            command.Parameters.AddWithValue("@1", textBox26.Text);
            command.Parameters.AddWithValue("@2", textBox27.Text);
            command.Parameters.AddWithValue("@3", textBox28.Text);
            command.Parameters.AddWithValue("@4", textBox23.Text);
            command.Parameters.AddWithValue("@5", textBox36.Text);
            command.Parameters.AddWithValue("@6", textBox37.Text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Товары", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView7.DataSource = table;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            class1.Delete(dataGridView7, textBox30.Text, "Товары");
        }
        private void RadioButton_CheckedChanged11(object sender, EventArgs e)
        {
            class1.Search(sender, dataGridView7, textBox29.Text, "Товары");
        }
        private void RadioButton_CheckedChanged12(object sender, EventArgs e)
        {
            class1.Oreder_By(sender, dataGridView7, "Товары");
        }

    }   
}

