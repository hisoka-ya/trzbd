﻿using System;
using System.Windows.Forms;

namespace ToyShop
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "User" && textBox2.Text == "12345")
            {
                forUsers forUsers = new forUsers();
                forUsers.Show();
                this.Hide();
            }
            else if (textBox1.Text == "Admin" && this.textBox2.Text == "12345")
            {
                Form1 forAdmins = new Form1();
                forAdmins.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }
    }
}
