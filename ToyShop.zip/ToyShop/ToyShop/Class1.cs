﻿using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ToyShop
{
    public class Class1
    {
        SqlConnection con = new SqlConnection("Data Source=HISOKA\\SQLEXPRESS;Initial Catalog=\"Toy shop\";Integrated Security=True");
        public void Oreder_By(object sender, DataGridView dgv, string tabel)
        {
            RadioButton selectedRadioButton = sender as RadioButton;
            SqlDataAdapter adapter = new SqlDataAdapter($"SELECT * FROM {tabel} ORDER BY {selectedRadioButton.Text}", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgv.DataSource = table;
        }
        public void Search(object sender, DataGridView dgv, string text, string tabel)
        {
            RadioButton selectedRadioButton = sender as RadioButton;
            SqlDataAdapter adapter = new SqlDataAdapter($"SELECT * FROM {tabel} WHERE {selectedRadioButton.Text}='{text}'", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgv.DataSource = table;
        }
        public void Delete(DataGridView d, string text, string tabel)
        {
            con.Open();
            SqlCommand command = new SqlCommand($"Delete from {tabel} where id=@id", con);
            command.Parameters.AddWithValue("@id", text);
            command.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter adapter = new SqlDataAdapter($"SELECT * FROM {tabel}", con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            d.DataSource = table;
        }
    }
}
